#include <LiquidCrystal_I2C.h>
#include <Wire.h>

class SmartAlarmClock
{
private:
    LiquidCrystal_I2C lcd{0x27, 16, 2};
    // Pin Assignments
    const int hourButton = 7;
    const int minuteButton = 3;
    const int stopButton = 2;
    const int buzzer = 9;
    const int photoResistorPin = A0;

    // Light Sensor Configuration
    const int lightThreshold = 400;
    unsigned long lastLightCheck = 0;
    const unsigned long LIGHT_CHECK_INTERVAL = 2000; // Check light every 2 seconds

    // Time Tracking Variables
    int hours = 5;
    int minutes = 59;
    int seconds = 58;
    int lastDisplaySeconds = -1;

    // Alarm Time Variables
    int alarmHours = 6;
    int alarmMinutes = 00;

    // State Variables
    bool buzzerRinging = false;
    bool alarmActive = true;
    unsigned long alarmStartTime = 0;
    const unsigned long alarmDuration = 60000; // 1 minute

    // User Customization
    char userName[11] = "Josephine";
    int nameEditIndex = 0;
    const int MAX_NAME_LENGTH = 10;

    // Timing and Debounce
    unsigned long lastSecondUpdate = 0;
    unsigned long lastButtonPress = 0;
    const unsigned long DEBOUNCE_DELAY = 200;

    // Tone Selection
    enum AlarmTone
    {
        CLASSIC_TONE,
        ASCENDING_TONE,
        MELODIC_TONE,
        URGENT_TONE
    };
    AlarmTone currentTone = CLASSIC_TONE;

    // Modes
    enum ClockMode
    {
        DISPLAY_TIME,
        SET_ALARM,
        SET_TIME,
        SET_USERNAME,
        SET_TONE // New mode for tone selection
    };
    ClockMode currentMode = DISPLAY_TIME;
    bool stateChanged = true;

public:
    void setup()
    {
        // Initialize LCD
        lcd.init();
        lcd.backlight();
        // Button Setup
        pinMode(hourButton, INPUT_PULLUP);
        pinMode(minuteButton, INPUT_PULLUP);
        pinMode(stopButton, INPUT_PULLUP);
        // Buzzer Setup
        pinMode(buzzer, OUTPUT);
        // Photoresistor Setup
        pinMode(photoResistorPin, INPUT);
        // Initial Display
        updateDisplay();
    }

    void loop()
    {
        // Update Time
        updateTime();
        // Check Buttons
        handleButtons();
        // Check Alarm
        checkAlarm();
        // Manage Backlight
        manageBacklight();
        if (stateChanged ||
            (currentMode == DISPLAY_TIME && seconds != lastDisplaySeconds))
        {
            updateDisplay();
            stateChanged = false;
            lastDisplaySeconds = seconds;
        }
    }

    void manageBacklight()
    {
        unsigned long currentMillis = millis();
        // Check light level periodically to reduce constant reading
        if (currentMillis - lastLightCheck >= LIGHT_CHECK_INTERVAL)
        {
            int lightLevel = analogRead(photoResistorPin);
            if (lightLevel < lightThreshold)
            {
                lcd.noBacklight(); // Dim environment, turn off backlight
            }
            else
            {
                lcd.backlight(); // Bright environment, keep backlight on
            }
            lastLightCheck = currentMillis;
        }
    }

    void updateTime()
    {
        unsigned long currentMillis = millis();
        if (currentMillis - lastSecondUpdate >= 1000)
        {
            lastSecondUpdate = currentMillis;
            seconds++;
            if (seconds >= 60)
            {
                seconds = 0;
                minutes++;
                if (minutes >= 60)
                {
                    minutes = 0;
                    hours++;
                    if (hours >= 24)
                    {
                        hours = 0;
                    }
                }
            }
        }
    }

    void handleButtons()
    {
        unsigned long currentMillis = millis();
        if (currentMillis - lastButtonPress < DEBOUNCE_DELAY)
            return;
        // Hour Button Logic
        if (digitalRead(hourButton) == LOW)
        {
            lastButtonPress = currentMillis;
            handleHourButton();
        }
        // Minute Button Logic
        if (digitalRead(minuteButton) == LOW)
        {
            lastButtonPress = currentMillis;
            handleMinuteButton();
        }
        // Stop Button Logic
        if (digitalRead(stopButton) == LOW)
        {
            lastButtonPress = currentMillis;
            handleStopButton();
        }
    }

    void handleHourButton()
    {
        stateChanged = true;
        switch (currentMode)
        {
        case DISPLAY_TIME:
            // Switch to Set Alarm Mode
            currentMode = SET_ALARM;
            break;
        case SET_ALARM:
            // Increment Alarm Hours
            alarmHours = (alarmHours + 1) % 24;
            break;
        case SET_TIME:
            // Increment Hours
            hours = (hours + 1) % 24;
            break;
        case SET_USERNAME:
            // Move to next character position
            nameEditIndex = (nameEditIndex + 1) % MAX_NAME_LENGTH;
            break;
        case SET_TONE:
            // No specific action for hour button in tone mode
            break;
        }
    }

    void handleMinuteButton()
    {
        stateChanged = true;
        switch (currentMode)
        {
        case DISPLAY_TIME:
            // Switch to Set Time Mode
            currentMode = SET_TIME;
            break;
        case SET_ALARM:
            // Increment Alarm Minutes
            alarmMinutes = (alarmMinutes + 1) % 60;
            break;
        case SET_TIME:
            // Increment Minutes
            minutes = (minutes + 1) % 60;
            seconds = 0; // Reset seconds when manually setting time
            break;
        case SET_USERNAME:
            // Change character at current position
            changeUsernameChar();
            break;
        case SET_TONE:
            // Cycle through tone options
            cycleTone();
            break;
        }
    }

    void handleStopButton()
    {
        stateChanged = true;
        // Stop Alarm
        if (buzzerRinging)
        {
            buzzerRinging = false;
            alarmActive = false;
            noTone(buzzer);
            lcd.clear(); // Clear the display
            lcd.setCursor(0, 0);
            lcd.print("  ALARM");
            lcd.setCursor(0, 1);
            lcd.print("  STOPPED");
            delay(2000);                // Show the message for 2 seconds
            currentMode = DISPLAY_TIME; // Return to DISPLAY_TIME mode
            updateDisplay();
        }
        else
        {
            // Cycle Modes
            switch (currentMode)
            {
            case DISPLAY_TIME:
                currentMode = SET_ALARM;
                break;
            case SET_ALARM:
                currentMode = SET_TIME;
                break;
            case SET_TIME:
                currentMode = SET_USERNAME;
                nameEditIndex = 0;
                break;
            case SET_USERNAME:
                currentMode = SET_TONE; // Add new mode transition
                break;
            case SET_TONE:
                currentMode = DISPLAY_TIME;
                break;
            }
        }
    }

    void cycleTone()
    {
        // Cycle through available tones
        currentTone = static_cast<AlarmTone>((currentTone + 1) % 4);

        // Preview the selected tone
        previewSelectedTone();
    }

    void previewSelectedTone()
    {
        switch (currentTone)
        {
        case CLASSIC_TONE:
            classicTone();
            break;
        case ASCENDING_TONE:
            ascendingTone();
            break;
        case MELODIC_TONE:
            melodicTone();
            break;
        case URGENT_TONE:
            urgentTone();
            break;
        }
    }

    void changeUsernameChar()
    {
        // Cycle through characters: space, A-Z
        if (userName[nameEditIndex] == ' ')
        {
            userName[nameEditIndex] = 'A';
        }
        else if (userName[nameEditIndex] == 'Z')
        {
            userName[nameEditIndex] = ' ';
        }
        else
        {
            userName[nameEditIndex]++;
        }
    }

    void updateDisplay()
    {
        lcd.clear();
        switch (currentMode)
        {
        case DISPLAY_TIME:
            displayNormalTime();
            break;
        case SET_ALARM:
            displayAlarmSetting();
            break;
        case SET_TIME:
            displayTimeSetting();
            break;
        case SET_USERNAME:
            displayUsernameSetting();
            break;
        case SET_TONE:
            displayToneSetting();
            break;
        }
    }

    void displayNormalTime()
    {
        // First Line: Greeting
        lcd.setCursor(0, 0);
        lcd.print("Hi, ");
        lcd.print(userName);
        lcd.print("!");
        // Second Line: Time and Alarm Status
        lcd.setCursor(0, 1);
        printDigits(hours);
        lcd.print(":");
        printDigits(minutes);
        lcd.print(":");
        printDigits(seconds);

        // Display "ALARM ON" if the alarm is ringing
        // if (buzzerRinging) {
        //     lcd.setCursor(9, 1);
        //     lcd.print("ALRM ON ");
        // } else {
        //     // Ambient Light Indicator
        //     lcd.setCursor(12, 1);
        //     int lightLevel = analogRead(photoResistorPin);
        //     // lcd.print(lightLevel < lightThreshold ? "DIM" : "BRT");
        // }
    }

    void displayAlarmSetting()
    {
        lcd.setCursor(0, 0);
        lcd.print("Set Alarm Time:");
        lcd.setCursor(0, 1);
        printDigits(alarmHours);
        lcd.print(":");
        printDigits(alarmMinutes);
    }

    void displayTimeSetting()
    {
        lcd.setCursor(0, 0);
        lcd.print("Set Clock Time:");
        lcd.setCursor(0, 1);
        printDigits(hours);
        lcd.print(":");
        printDigits(minutes);
        lcd.print(":");
        printDigits(seconds);
    }

    void displayUsernameSetting()
    {
        lcd.setCursor(0, 0);
        lcd.print("Edit Username:");
        lcd.setCursor(0, 1);
        lcd.print(userName);
        // Highlight current editing character
        lcd.setCursor(nameEditIndex, 1);
        lcd.blink();
    }

    void displayToneSetting()
    {
        lcd.setCursor(0, 0);
        lcd.print("Select Tone:");
        lcd.setCursor(0, 1);
        switch (currentTone)
        {
        case CLASSIC_TONE:
            lcd.print("Classic Tone");
            break;
        case ASCENDING_TONE:
            lcd.print("Ascending");
            break;
        case MELODIC_TONE:
            lcd.print("Melodic");
            break;
        case URGENT_TONE:
            lcd.print("Urgent");
            break;
        }
    }

    void checkAlarm()
    {
        // Check if current time matches alarm time
        if (hours == alarmHours && minutes == alarmMinutes && seconds < 59)
        {
            activateAlarm();
        }
        // Handle Alarm Duration
        if (buzzerRinging && millis() - alarmStartTime >= alarmDuration)
        {
            stopAlarm();
        }
    }

    void activateAlarm()
    {
        if (!alarmActive)
            return;
        buzzerRinging = true;
        alarmStartTime = millis();
        lcd.backlight(); // Turn on backlight when alarm rings

        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("     ALARM");
        lcd.setCursor(0, 1);
        lcd.print("      ON");

        triggerAlarmSound();
        stateChanged = true;

        updateDisplay();
    }

    void triggerAlarmSound()
    {
        // Trigger tone based on current selection
        switch (currentTone)
        {
        case CLASSIC_TONE:
            classicTone();
            break;
        case ASCENDING_TONE:
            ascendingTone();
            break;
        case MELODIC_TONE:
            melodicTone();
            break;
        case URGENT_TONE:
            urgentTone();
            break;
        }
    }

    // Different Tone Implementations
    void classicTone()
    {
        tone(buzzer, 1000, 500); // 1kHz tone
        delay(600);
        tone(buzzer, 1200, 500); // Higher pitch
        delay(600);
        tone(buzzer, 800, 500); // Lower pitch
    }

    void ascendingTone()
    {
        for (int i = 500; i <= 1500; i += 200)
        {
            tone(buzzer, i, 300);
            delay(400);
        }
    }

    void melodicTone()
    {
        int melody[] = {262, 294, 330, 349, 392, 440, 494, 523};        // Notes: C4, D4, E4, F4, G4, A4, B4, C5
        int noteDurations[] = {500, 500, 500, 500, 500, 500, 500, 500}; // Duration for each note in ms
        for (int i = 0; i < 8; i++)
        {
            tone(buzzer, melody[i], noteDurations[i]);
            delay(noteDurations[i] + 100); // Add a short pause between notes
        }
    }

    void urgentTone()
    {
        for (int i = 0; i < 5; i++)
        {
            tone(buzzer, 1500, 200); // High-frequency, short bursts
            delay(250);
            tone(buzzer, 1800, 200);
            delay(250);
        }
    }

    void stopAlarm()
    {
        buzzerRinging = false;
        noTone(buzzer);
        stateChanged = true;
    }

    void printDigits(int digits)
    {
        if (digits < 10)
        {
            lcd.print("0");
        }
        lcd.print(digits);
    }
};

SmartAlarmClock alarmClock;

void setup()
{
    alarmClock.setup();
}

void loop()
{
    alarmClock.loop();
}